<script>
jQuery(document).ready(function() {
		jQuery('#upload_img_button_vp1_html5').click(function() {
		 formfield = 'preview';
		 the_i='show';
		 tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
		 return false;
		});	
	
	
		window.send_to_editor = function(html) {
		 imgurl = jQuery('img',html).attr('src');
		 //jQuery('#'+formfield).val(imgurl);
		 document.forms["form-playlist-vp1html5"].preview.value=imgurl;

		 //alert (the_i); 	
		 jQuery('#'+formfield+'_'+the_i).attr('src',imgurl);
		 tb_remove();
		 
		}
});		
</script>

<div class="wrap">
	<div id="lbg_logo">
			<h2>Player Settings for player: <span style="color:#FF0000; font-weight:bold;"><?php echo $_SESSION['xname']?> - ID #<?php echo $_SESSION['xid']?></span></h2>
 	</div>
  <form id="form-playlist-vp1html5" method="POST" enctype="multipart/form-data" action="?page=LBG_VP1_HTML5_Settings">
	<script>
	jQuery(function() {
		var icons = {
			header: "ui-icon-circle-arrow-e",
			headerSelected: "ui-icon-circle-arrow-s"
		};
		jQuery( "#accordion" ).accordion({
			icons: icons,
			autoHeight: false
		});
	});
	</script>


<div id="accordion">
  <h3><a href="#">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Video Sources</a></h3>
  <div style="padding:30px;">
    <table class="wp-list-table widefat fixed pages" cellspacing="0">

      <tr>
        <td align="right" valign="top" class="row-title" width="30%">Movie Title</td>
        <td align="left" valign="middle" width="76%"><input name="movieTitle" type="text" size="55" id="movieTitle" value="<?php echo stripslashes($_POST['movieTitle']);?>"/></td>
      </tr>
      <tr>
        <td width="30%" align="right" valign="top" class="row-title">Movie Description</td>
        <td width="76%" align="left" valign="middle"><textarea name="movieDesc" id="movieDesc" cols="55" rows="5"><?php echo stripslashes($_POST['movieDesc']);?></textarea></td>
      </tr>
		  <tr>
            <td align="right" valign="top" class="row-title">Preview</td>
		    <td align="left" valign="top"><input name="preview" type="text" id="preview" size="50" value="<?php echo stripslashes($row['preview']);?>" />
              <input name="upload_img_button_vp1_html5" type="button" id="upload_img_button_vp1_html5" value="Change Image" />
              <br />
              Enter an URL or upload an image<br />
            <? if ($_POST['preview']) { ?>
            	<p><img src="<?php echo $_POST['preview']?>" border="0" align="top" name="preview_show" id="preview_show" /></p>
            <?php } ?>
            </td>
	    </tr>
          <tr>
            <td colspan="2" align="left" valign="top" class="row-title">
              <ul>
              <li><u>CASE 1: Videos hosted on THE SAME server as your website:</u><br />
Using a FTP client (or the CPannel or a FTP plugin for Wordpress) upload your videos (.mp4, .webm) in the following folder: 
                wp-content/plugins/lbg-vp1-html5/lbg_vp1_html5/videos/<br />
                Then paste below just the file name. <br />
                Ex: big_buck_bunny_trailer.mp4</li>
              <li><u>CASE 2: Videos hosted on ANOTHER server as your website:</u><br />
                Paste below the url to the video.<br />
                Ex: http://lambertgroupproductions.com/canyon/vp2_html5/rightSidePlaylist/videos/big_buck_bunny_trailer.mp4</li>                
              </ul> 
            </td>
          </tr>
          <tr>
        <td align="right" valign="top" class="row-title">MP4 file (Chrome, IE, Safari)       </td>
        <td align="left" valign="middle"><input name="mp4" type="text" size="80" id="mp4" value="<?php echo stripslashes($_POST['mp4'])?>"/></td>
      </tr>
      <tr>
        <td align="right" valign="top" class="row-title">WebM</td>
        <td align="left" valign="middle"><input name="webm" type="text" size="80" id="webm" value="<?php echo stripslashes($_POST['webm']);?>"/></td>
      </tr>

    </table>
  </div>  


  <h3><a href="#">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;General Settings</a></h3>
  <div style="padding:30px;">
	  <table class="wp-list-table widefat fixed pages" cellspacing="0">
     
		  <tr>
		    <td align="right" valign="top" class="row-title" width="30%">Player Name</td>
		    <td align="left" valign="top" width="70%"><input name="name" type="text" size="40" id="name" value="<?php echo $_SESSION['xname'];?>"/></td>
	      </tr>
		  <tr>
            <td width="25%" align="right" valign="top" class="row-title">Player Width</td>
		    <td width="75%" align="left" valign="top"><input name="playerWidth" type="text" size="25" id="playerWidth" value="<?php echo $_POST['playerWidth'];?>"/></td>
	    </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title">Player Height</td>
		    <td align="left" valign="top"><input name="playerHeight" type="text" size="25" id="playerHeight" value="<?php echo $_POST['playerHeight'];?>"/></td>
	    </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title">Skin Name</td>
		    <td align="left" valign="middle"><select name="skin" id="skin">
		      <option value="universalBlack" <?php echo (($_POST['skin']=='universalBlack')?'selected="selected"':'')?>>universalBlack</option>
		      <option value="universalWhite" <?php echo (($_POST['skin']=='universalWhite')?'selected="selected"':'')?>>universalWhite</option>
		      <option value="giant" <?php echo (($_POST['skin']=='giant')?'selected="selected"':'')?>>giant</option>
		      <option value="futuristicElectricBlue" <?php echo (($_POST['skin']=='futuristicElectricBlue')?'selected="selected"':'')?>>futuristicElectricBlue</option>
		      <option value="futuristicChrome" <?php echo (($_POST['skin']=='futuristicChrome')?'selected="selected"':'')?>>futuristicChrome</option>
		      <option value="elegantMinimal" <?php echo (($_POST['skin']=='elegantMinimal')?'selected="selected"':'')?>>elegantMinimal</option>
            </select></td>
	      </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title">Seek Bar Adjust</td>
		    <td align="left" valign="middle"><input name="seekBarAdjust" type="text" size="25" id="seekBarAdjust" value="<?php echo $_POST['seekBarAdjust'];?>"/>
            <p>Recommended values: </p>
            <p>
	- universalBlack: 220<br />
- universalWhite: 220<br />
- giant: 390<br />
- futuristicElectricBlue: 255<br />
- futuristicChrome: 255<br />
- elegantMinimal: 0</p>
            </td>
	      </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title">Show Information Button</td>
		    <td align="left" valign="middle"><select name="showInfo" id="showInfo">
              <option value="true" <?php echo (($_POST['showInfo']=='true')?'selected="selected"':'')?>>true</option>
              <option value="false" <?php echo (($_POST['showInfo']=='false')?'selected="selected"':'')?>>false</option>
            </select></td>
	    </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title">Preload</td>
		    <td align="left" valign="middle"><select name="preload" id="preload">
		      <option value="auto" <?php echo (($_POST['preload']=='auto')?'selected="selected"':'')?>>auto</option>
		      <option value="metadata" <?php echo (($_POST['preload']=='metadata')?'selected="selected"':'')?>>metadata</option>
		      <option value="none" <?php echo (($_POST['preload']=='none')?'selected="selected"':'')?>>none</option>
            </select></td>
	      </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title">Loop Video</td>
		    <td align="left" valign="middle"><select name="loop" id="loop">
              <option value="loop" <?php echo (($_POST['loop']=='loop')?'selected="selected"':'')?>>true</option>
              <option value="" <?php echo (($_POST['loop']=='')?'selected="selected"':'')?>>false</option>
            </select></td>
	    </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title">Auto Play</td>
		    <td align="left" valign="middle"><select name="autoPlay" id="autoPlay">
              <option value="autoplay" <?php echo (($_POST['autoPlay']=='autoplay')?'selected="selected"':'')?>>true</option>
              <option value="" <?php echo (($_POST['autoPlay']=='')?'selected="selected"':'')?>>false</option>
            </select></td>
	    </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title">Initial Volume Value</td>
		    <td align="left" valign="middle"><script>
	jQuery(function() {
		jQuery( "#initialVolume-slider-range-min" ).slider({
			range: "min",
			value: <?php echo $_POST['initialVolume'];?>,
			min: 0,
			max: 1,
			step: 0.1,
			slide: function( event, ui ) {
				jQuery( "#initialVolume" ).val(ui.value );
			}
		});
		jQuery( "#initialVolume" ).val( jQuery( "#initialVolume-slider-range-min" ).slider( "value" ) );
	});
	        </script>
                <div id="initialVolume-slider-range-min" class="inlinefloatleft"></div>
		      <div class="inlinefloatleft" style="padding-left:20px;">
		        <input name="initialVolume" type="text" size="10" id="initialVolume" style="border:0; color:#000000; font-weight:bold;"/>
	          </div></td>
	    </tr>
      </table>
  </div>
    
  

  
</div>

<div style="text-align:center; padding:20px 0px 20px 0px;"><input name="Submit" type="submit" id="Submit" class="button-primary" value="Update Player Settings"></div>

</form>
</div>