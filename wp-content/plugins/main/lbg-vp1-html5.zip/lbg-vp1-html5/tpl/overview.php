<div class="wrap">
		<div id="lbg_logo">
			<h2>Overview</h2>
		</div>
		<div class="postbox-container" style="width:100%">
			<div class="postbox">
				<h3 style="padding:7px 10px;">LambertGroup - HTML5 Video Player with Multiple Skins</h3>
				<div class="inside">		
				<p>
					This plugin will allow you to insert an HTML5 Video Player with Multiple Skins.
				</p>
				<p>You have available the following sections:</p> 
				<ul class="lbg_list-1">
					<li><a href="?page=LBG_VP1_HTML5_Manage_Players">Manage Players</a></li>
					<li><a href="?page=LBG_VP1_HTML5_Add_New">Add New</a> (player)</li>
					<li><a href="?page=LBG_VP1_HTML5_Settings">Player Settings</a> (you have to choose a player first from &quot;Manage Players&quot; section. The first one is set as default)</li>
          <li><a href="?page=LBG_VP1_HTML5_Help">Help</a></li> 
				</ul>
			  </div>
			</div>	
		</div>
	</div>